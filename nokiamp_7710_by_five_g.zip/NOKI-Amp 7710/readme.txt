NOKI-Amp� [ NOKIA 7710 native style ]
>> release date 22.MAR.2002

� Sergium Graphics
Special thanks to Jesus Christ for gifts He gave me.